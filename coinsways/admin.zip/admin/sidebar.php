 <div class="sidebar" data-color="purple" data-image="img/sidebar-1.jpg">
			<!--
		        Tip 1: You can change the color of the sidebar using: data-color="purple | blue | green | orange | red"

		        Tip 2: you can also add an image using data-image tag
		    -->

			<div class="logo">
				<a href="#" class="simple-text">
                    <img src="../img/logo_bg.png" class="img-responsive"/>
				</a>
			</div>

	    	<div class="sidebar-wrapper">
	            <ul class="nav">
	                <li class="active">
	                    <a href="index.php">
	                        <i>Dashboard</i>
	                        <p>&nbsp;</p>
	                    </a>
	                </li>

	                 <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">Affiliate <span class="caret"></span></a>
                        <ul class="dropdown-menu drop-menu">
                            <li><a href="Direct-Referal.php">Direct Referral</a></li>
                            <li><a href="MyTeam.php">Affiliate Team</a></li>
                        </ul>
                    </li>

                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">Income  <span class="caret"></span></a>
                        <ul class="dropdown-menu drop-menu">
                            <li><a href="Referal-comission.php">Referal Income</a></li>
                             <li><a href="Income-Daily-Growth.php">Growth Income</a></li>
                            <li><a href="Daily-Growth.php">Daily Growth</a></li>
                        </ul>
                    </li>
	                
	                 <li class="dropdown">
                       <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">Withdrawals <span class="caret"></span></a>
                        <ul class="dropdown-menu drop-menu">
                            <li><a href="Withdrawal-new.php">New Withdrawal</a></li>
                            
                        </ul>
                    </li>

                     <li class="dropdown">
                       <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">Payments <span class="caret"></span></a>
                        <ul class="dropdown-menu drop-menu">
                            <li><a href="Upload_payment_slip.php">Purchase Plan</a></li>
                            
                        </ul>
                    </li>

                      <li class="dropdown">
                          <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">Help Desk <span class="caret"></span></a>
                        <ul class="dropdown-menu drop-menu">
                       <li><a href="Helpdesk.php">Help Desk</a></li>
                            </ul>
                    </li>

                     <li class="dropdown">
                         <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">Profile <span class="caret"></span></a>
                        <ul class="dropdown-menu drop-menu">
                       <li><a href="profile.php">User Profile</a></li>
                            </ul>
                    </li>
	             
	               
					
	            </ul>
	    	</div>
	    </div>
